Download Python File

Pip install the following libarys 
numpy scipy odeint matplotlib 

Insert Intial Values and Degree 
# The ODE is 𝑓(𝑥,𝑦)= −𝑦+𝑙𝑛𝑥 ,𝑥0=2,𝑦0=1,ℎ=0.3
y0 = 1  # initial values
x0 = 2
h = 0.3  # step

Run File