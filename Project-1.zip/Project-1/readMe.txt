Installation of (Numpy, SciPy, and Matplotlib)
=============================================
Installation of packages
Inside the Terminal
type command 
!pip install <package name>
Once packages are all installed, run a file 